Group 11 Project 

1. Download the dataset from https://www.kaggle.com/karangadiya/fifa19 
2. Name it data.csv and upload it on google drive
3. Run Part 1 of code, it will create 2 new csv files that get stored in the same google drive
4. Run Part 2 and Part 3 of the code

Thank you
